//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
//

// 3.1.0.24   -->  WinPcap  3.1 beta4
// 3.1.0.27   -->  WinPcap  3.1 RTM
// 3.2.0.29	  -->  WinPcap  3.2 alpha1
// 4.0.0.374  -->  WinPcap  4.0 alpha1
// 4.0.0.592  -->  WinPcap  4.0 beta1
// 4.0.0.655  -->  WinPcap  4.0 beta2
// 4.0.0.703  -->  WinPcap  4.0 beta3
// 4.0.0.755  -->  WinPcap  4.0 RTM

#define WINPCAP_MAJOR	4
#define WINPCAP_MINOR	0
#define WINPCAP_REV		0
#define WINPCAP_BUILD	755
#define WINPCAP_VER_STRING	"4.0.0.755"
#define WINPCAP_PACKET9x_STRING_VERSION	"4.0"
#define WINPCAP_WPCAP_STRING_VERSION "4.0"

#define WINPCAP_COMPANY_NAME 			"CACE Technologies"

#define WINPCAP_PRODUCT_NAME 			"WinPcap"

#define WINPCAP_COPYRIGHT_STRING 		"Copyright � 2005-2007 CACE Technologies. Copyright � 1999-2005 NetGroup, Politecnico di Torino."
#define WINPCAP_WANPACKET_COPYRIGHT_STRING "Copyright � 2005-2007 CACE Technologies. Copyright � 2003-2005 NetGroup, Politecnico di Torino."
#define WINPCAP_INSTALLERHELPER_COPYRIGHT_STRING "Copyright � 2007 CACE Technologies."
#define WINPCAP_RPCAPD_COPYRIGHT_STRING "Copyright � 2005-2007 CACE Technologies. Copyright � 2003-2005 NetGroup, Politecnico di Torino."

#define WINPCAP_BUILD_DESCRIPTION 		""
#define WINPCAP_PRIVATE_BUILD			""
#define WINPCAP_LIBPCAP_VERSION			"0.9.5"
